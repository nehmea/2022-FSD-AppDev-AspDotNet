using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Blog.Pages
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
